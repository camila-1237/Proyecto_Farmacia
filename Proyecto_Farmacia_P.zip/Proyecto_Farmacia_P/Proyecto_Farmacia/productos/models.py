from django.db import models
from tipos_productos.models import TipoProducto
from django.utils import timezone

class Producto(models.Model):
    id_producto = models.AutoField(primary_key=True)
    nombre = models.CharField(max_length=100)
    codigo_barras = models.CharField(max_length=13, unique=True)
    precio = models.DecimalField(max_digits=10, decimal_places=2)
    fecha_caducidad = models.DateTimeField()
    cantidad_inventario = models.PositiveIntegerField()
    tipo = models.ForeignKey(TipoProducto, on_delete=models.CASCADE)

    def __str__(self):
        return self.nombre

class Venta(models.Model):
    id_venta = models.AutoField(primary_key=True)
    fecha_venta = models.DateTimeField(default=timezone.now)
    finalizada = models.BooleanField(default=False)
    total = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    productos = models.TextField()

    def calcular_total(self):
        transacciones = self.transaccion_set.all()
        total = sum(transaccion.calcular_subtotal() for transaccion in transacciones)
        self.total = total
        self.save()
        return round(total, 2)

    def __str__(self):
        return f'Venta {self.id_venta}'

class Transaccion(models.Model):
    id_transaccion = models.AutoField(primary_key=True)
    id_producto = models.ForeignKey(Producto, on_delete=models.CASCADE)
    id_venta = models.ForeignKey(Venta, on_delete=models.CASCADE)
    cantidad = models.PositiveIntegerField()
    finalizada = models.BooleanField(default=False)
    
    def calcular_subtotal(self):
        return self.cantidad * self.id_producto.precio

    def detalles_producto_vendido(self):
        return f'{self.id_producto.nombre} - Cantidad: {self.cantidad}'

    def __str__(self):
        return f'Transacción: {self.id_producto.nombre} en Venta {self.id_venta.id_venta}'
"""
class Venta(models.Model):
    id_venta = models.AutoField(primary_key=True)
    fecha_venta = models.DateTimeField(auto_now_add=True)
    finalizada = models.BooleanField(default=False)
    productos = models.ManyToManyField(Producto, through='Transaccion')

    def calcular_total(self):
        transacciones = Transaccion.objects.filter(venta=self)
        total = sum(transaccion.calcular_subtotal() for transaccion in transacciones)
        return total

    def __str__(self):
        return f'Venta {self.id_venta}'

class Transaccion(models.Model):
    id_transaccion = models.AutoField(primary_key=True)
    producto = models.ForeignKey(Producto, on_delete=models.CASCADE)
    venta = models.ForeignKey(Venta, on_delete=models.CASCADE)
    cantidad = models.PositiveIntegerField()
    finalizada = models.BooleanField(default=False)
    
    def calcular_subtotal(self):
        return self.cantidad * self.producto.precio

    def __str__(self):
        return f'Transacción: {self.producto.nombre} en Venta {self.venta.id}'
class Venta(models.Model):
    id_venta = models.AutoField(primary_key=True)
    fecha_venta = models.DateTimeField(auto_now_add=True)
    finalizada = models.BooleanField(default=False)

    def calcular_total(self):
        transacciones = self.transaccion_set.all()
        total = sum(transaccion.calcular_subtotal() for transaccion in transacciones)
        return total

    def finalizar_venta(self):
        self.finalizada = True
        self.save()

    def __str__(self):
        return f'Venta {self.id_venta}'

class Transaccion(models.Model):
    id_transaccion = models.AutoField(primary_key=True)
    producto = models.ForeignKey(Producto, on_delete=models.CASCADE)
    venta = models.ForeignKey(Venta, on_delete=models.CASCADE)
    cantidad = models.PositiveIntegerField()
    finalizada = models.BooleanField(default=False)

    def calcular_subtotal(self):
        return self.cantidad * self.producto.precio

    def finalizar_transaccion(self):
        self.finalizada = True
        self.save()

    def __str__(self):
        return f'Transacción: {self.producto.nombre} en Venta {self.venta.id}'"""

